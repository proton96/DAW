"use strict";

// Arrays de colores
const digitos_hexadecimales = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"];
const colores_nombres = ["red", "blue", "green", "yellow", "purple", "orange", "pink", "brown", "cyan", "magenta"];

// Selección de elementos del DOM


// Función para generar un color hexadecimal aleatorio
function generarColorHexadecimal() {

}

// Función para seleccionar un color por nombre aleatorio
function generarColorPorNombre() {

}

// Función para aplicar el color al fondo y actualizar el texto
function aplicarColor(color) {

}

// Eventos de los botones

