"use strict";

// SELECCIONAR ELEMENTOS PARA MOSTRAR INFORMACION


// SELECCIONAR BOTONES
//const decreaseBtn;
//const resetBtn;
//const increaseBtn;

let counter = 0; // Valor inicial del contador

// PROGRAMAR CADA ACCION (decrease, reset, increase)


// FUNCIÓN PARA ACTUALIZAR EL CONTADOR
function updateCounter() {
    
}
