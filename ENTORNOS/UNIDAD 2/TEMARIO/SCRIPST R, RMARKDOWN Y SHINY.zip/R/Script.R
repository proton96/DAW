# Carlos            #
# Aprendizaje de R  #
# 21/11/2024        #

rm(list = ls())

# Insertar librerías ------------------------------------------------------

#library(rstudioapi)
#versionInfo()


# Código ------------------------------------------------------------------

# Declaración de variables
a <- 2
b <- 3

# Operadores --------------------------------------------------------------
a+b
a-b
a*b
a/b
b %% a
b %/% a
a^b
sqrt(b)
is.na(a)
NA
c <- NA
is.na(c)
NULL
is.null(a)
is.null(NULL)
!a
d <- 0
!d
d

# Condicionales y bucles --------------------------------------------------
d
if(d==0){
  print("d es 0")
} else{
  print("d es distinto de 0")
}

for(i in 1:10){
  print(i)
}

i <- 10
while(i>0){
  print(i)
  i <- i-1
}

# Tipos
typeof(a)
typeof("a")
typeof(integer(1))
typeof(1)

as.logical(1)
as.numeric("1.32")



# Funciones ---------------------------------------------------------------

comprobador_0 <- function(num){
  if(num==0){
    print(paste(num, "es 0"))
  } else{
    print(paste(num, "es distinto de 0"))
  }
}

iterador_rango <- function(ini, fin){
  for(i in ini:fin){
    comprobador_0(i)
  }
}

comprobador_0(26)
iterador_rango(10,14)

# Estructuras de datos ----------------------------------------------------

# Vectores

v <- c(1,2,3,4)
v
v[1]
v[4]
v[2:4]
2:4
v2 <- 10:1
v2
order(v2)
v2[order(v2)]
v2[v]
v2
v3 <- seq(-18,0,2)
length(v3)
length(v2)
length(v2)==length(v3)
v2+v3
v3-v2
v2*v3
v2^v3

# Matrix

m1 <- matrix(1:9, nrow = 3, ncol=3)
m2 <- matrix(2, nrow = 3, ncol=3)
m1*m2
m1+m2
m1[,1] # Columna
m1[1,] # Fila

# Dataframe

df1 <- data.frame(m1)
names(df1) <- c("Altura Pelo", "Peso", "Medida_pie")
df1$Altura
df1[,1]
df1[1,1]
df1[1,]
rownames(df1) <- c("Pedro", "María", "Eva")
rownames(df1) <- NULL
df1[3:1,]
df1[,"Altura"]
df1["Altura"]

df_alumnos <- data.frame(
  Nombre=c("Iván", "Javi", "Lara", "Ríos"),
  Sexo=factor(c("H", "H", "H", "H"), c("H", "M")),
  Nota=c(10.0, 9.7, 9.8,6.4)
)

str(df_alumnos)
summary(df_alumnos)

# Dónde estoy - working directory
getwd()
setwd("")

path <- "C:/Users/2DAM/Documents/ED/"

paste("Hola", "mundo", sep = " ")
paste0("Hola", "mundo")

#Help
?read.csv
??sequen # curiosidad

write.csv(df1, paste0(path, "datos_R.csv"), row.names = F)

# Lo miro para el proximo dia
read.csv(paste0(path, "datos_R.csv"), header = T)
read.csv2(paste0(path, "datos_R.csv"), header = TRUE, sep = ",", quote = "\"", dec = ",",
          fill = TRUE, comment.char = "")


# Iris --------------------------------------------------------------------

# https://rpubs.com/MrCristianrl/502285

library(ISLR)
library(ggplot2)
library(caTools)
library(class)

df <- iris
str(df)

any(is.na(df))

ggplot(df, aes(Sepal.Width, Sepal.Length)) +
  geom_point(aes(col=Petal.Width,
                 size=Petal.Length,
                 shape = Species)) +
  ggtitle("Longitud y anchura del sépalo según la especie") +
  labs(x="Anchura del sépalo",
       y="Longitud del sépalo",
       col="Especie")

ggplot(df, aes(Sepal.Width, Sepal.Length)) +
  geom_point(aes(col=Species), size=2) +
  ggtitle("Longitud y anchura del sépalo según la especie") +
  labs(x="Anchura del sépalo",
       y="Longitud del sépalo",
       col="Especie") +
  theme_minimal()
ggsave(paste0(path, "sepalo.png"),
       width = 8, height = 6, bg = "white")

ggplot(df, aes(Petal.Width, Petal.Length)) +
  geom_point(aes(col=Species), size=2) +
  ggtitle("Longitud y anchura del pétalo según la especie") +
  labs(x="Anchura del pétalo",
       y="Longitud del pétalo",
       col="Especie") +
  theme_minimal()
ggsave(paste0(path, "petalo.png"),
       width = 8, height = 6, bg = "white")


ggplot(df, aes(y=Petal.Width)) +
  geom_boxplot(aes(fill=Species)) +
  theme_minimal() +
  ggtitle("Diagrama de cajas para el pétalo")

df.numeric <- df[,1:4]
specie <- df[,5]
df.scaled <- data.frame(scale(df.numeric))
sapply(df.scaled, var)
sapply(df.scaled, mean)


df.final <-  cbind(df.scaled, specie)
sample <- sample.split(df.final$specie, SplitRatio = .70)
train.data <- subset(df.final, sample==TRUE)
test.data <- subset(df.final, sample==FALSE)

predicted.species <- knn(train.data[1:4],
                         test.data[1:4],
                         train.data[,5],
                         k=1)
head(predicted.species)

sum(test.data[,5]==predicted.species) / dim(test.data)[1]
