package documentacion;


public class ProductoAlimenticio {
    private String nombre;
    private String tipo;
    private double precio;
    private boolean refrigerado;


    public ProductoAlimenticio(String nombre, String tipo, double precio, boolean refrigerado) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.refrigerado = refrigerado;
    }


    public String getNombre() {
        return nombre;
    }


    public String getTipo() {
        return tipo;
    }


    public double getPrecio() {
        return precio;
    }


    public boolean necesitaRefrigeracion() {
        return refrigerado;
    }


    public boolean esCaro() {
        return precio > 10;
    }
}
