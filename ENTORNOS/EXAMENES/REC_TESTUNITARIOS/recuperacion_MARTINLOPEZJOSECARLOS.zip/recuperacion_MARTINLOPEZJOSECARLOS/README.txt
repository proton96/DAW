Importaciones que te recomiendo:
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

Assert a usar:
assertEquals
assertThrows

Estructura de assertThrows:
assertThrows(IllegalArgumentException.class, () -> {

});

Pista:
algunos métodos contienen errores