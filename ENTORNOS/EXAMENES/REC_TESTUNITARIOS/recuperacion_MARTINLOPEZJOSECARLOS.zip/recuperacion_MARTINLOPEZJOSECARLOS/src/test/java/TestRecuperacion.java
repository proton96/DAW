import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;



public class TestRecuperacion {
        
    @Test
    void testMax(){
        int[] a = {1, 2, 3, 4, 5};
        assertEquals(5, Recuperacion.max(a));
        int[] b = {-1, -2, -3, -4, -5};
        assertEquals(-1, Recuperacion.max(b));
        int[] c = {5, 5, 5, 5, 5};
        assertEquals(5, Recuperacion.max(c));
        int[] d = {1};
        assertEquals(1, Recuperacion.max(d));
        assertThrows(IllegalArgumentException.class, () -> Recuperacion.max(null));
        
        
    }

    @Test
    void testContarPositivos(){
        int[] a = {1, -2, 3, -4, 5};
        assertEquals(3, Recuperacion.contarPositivos(a));
        int[] b = {-1, -2, -3, -4, -5};
        assertEquals(0, Recuperacion.contarPositivos(b));
        int[] c = {1, 2, 3, 4, 5};
        assertEquals(5, Recuperacion.contarPositivos(c));
        int[] d = {0, 0, 0, 0, 0};
        assertEquals(0, Recuperacion.contarPositivos(d));
        
    }

    @Test
    void testprimeraPosPar(){
        int[] a = {2 , 3 , 4 , 5 , 6};
        assertEquals(0, Recuperacion.primeraPosPar(a));
        int[] b = {-2 , 3 , 4 , 5 , 6};
        assertEquals(0, Recuperacion.primeraPosPar(b));
        int[] c = {3 , 3 , 4 , 5 , 6};
        assertEquals(2, Recuperacion.primeraPosPar(c));
        int[] d = {3 , 3 , 3 , 5 , 6};
        assertEquals(4, Recuperacion.primeraPosPar(d));
        int[] e = {3 , 3 , 3 , 5 , 3};
        assertEquals(null, Recuperacion.primeraPosPar(e));
    }

    
}
