/*
Dadas las siguientes funciones se pide:
1. Diseñar e implementar los tests unitarios necesarios (JUnit 5) para comprobar el funcionamiento correcto de todos los métodos.
2. Detectar y corregir los posibles errores existentes en la implementación.
*/

public class Recuperacion {
    public static int max(int[] a) {
        if (a == null || a.length == 0) {
            throw new IllegalArgumentException("El array no puede estar vacío");
        }
        int m = a[0];
        for (int i = 1; i < a.length; i++) {
            if (a[i] > m){
                m = a[i];
            }
        }
        return m;
    }

    public static int contarPositivos(int[] a) {
        int c = 0;
        for (int x : a) {
            if (x > 0){
                c++;
            }
        }
        return c;
    }

    public static int primeraPosPar(int[] a) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 == 0){
                return i;
            }
        }
        return -1;
    }
}
