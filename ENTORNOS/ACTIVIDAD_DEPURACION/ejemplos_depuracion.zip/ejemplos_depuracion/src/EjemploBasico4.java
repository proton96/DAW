import java.util.Random;

public class EjemploBasico4 {

    public static void main(String[] args) {
        Random generador = new Random();
        int resultado, aleatorio;
        resultado = 0;

        for (int i = 0; i < 5; i++) {
            aleatorio = generador.nextInt(5);
            resultado += aleatorio;
            resultado -= Math.sqrt(aleatorio) + Math.abs(-4);
            resultado *= 2;
            resultado *= -1;
            System.out.println(resultado);
        }

        System.out.println(resultado);

    }
}
