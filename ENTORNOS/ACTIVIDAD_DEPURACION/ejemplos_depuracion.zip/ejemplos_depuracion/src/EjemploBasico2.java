public class EjemploBasico2 {

    public static void main(String[] args) {
        int[] datos={12,43,9,4,61,-10,3,32,-76,89,12,5,-56};
        int mayor;
        
        mayor=datos[0];
        for (int i = 1; i <datos.length ; i++) {
            if(datos[i]>mayor){
                mayor=datos[i];
            }
        }
        
        System.out.println("El mayor es:"+mayor);
        
    }

}
