import java.util.Random;

public class EjemploBasico1 {

    public static void main(String[] args) {
        Random generador=new Random();
        int n;
        
        n = generador.nextInt();
        if (n % 2 == 0) {
            System.out.println("Es par");
        } else {
            System.out.println("Es impar");
        }

    }

}
