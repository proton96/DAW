import java.util.Scanner;

public class EjemploBasico3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        
        System.out.println("El tamaño del dibujo");
        n=teclado.nextInt();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j<= n; j++) {
                if( (i+j) % 2 == 0){
                    System.out.print("☺");
                }else{
                    System.out.print("☻");
                }
            }
            System.out.println("");
        }
    }

}