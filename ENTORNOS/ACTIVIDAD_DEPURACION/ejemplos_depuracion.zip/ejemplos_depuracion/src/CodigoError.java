public class CodigoError {

    public static void main(String[] args) {
        int[] datos={43,-76,9,-32,61,-10,3,32,74,53,12,5,-56};
        int menor;
        
        menor=datos[0];
        for (int i = 2; i <datos.length-1 ; i++) {
            if(datos[i]>menor){
                menor=datos[i];
            }
        }

        System.out.println("El menor es:"+menor);
        
    }

}
