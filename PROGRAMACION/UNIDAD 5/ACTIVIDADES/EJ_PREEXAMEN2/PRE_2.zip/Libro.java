import java.util.Scanner;

public class Libro extends Obra{
    private int numeroPaginas;
    private String genero;

    public Libro(String titulo, String autor, int anioPublicacion, int numeroPaginas, String genero) {
        super(titulo, autor, anioPublicacion);
        this.numeroPaginas = numeroPaginas;
        this.genero = genero;
    }

    public Libro(int numeroPaginas, String genero) {
        this.numeroPaginas = numeroPaginas;
        this.genero = genero;
    }


    @Override
    public void mostrarResumen() {
        System.out.println( "Libro{" +
                "genero='" + genero + '\'' +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", numeroPagina=" + numeroPaginas +
                '}');
    }

    @Override
    public void mostrarDetalles() {
        System.out.println( "Libro{" +
                "genero='" + genero + '\'' +
                ", numeroPagina=" + numeroPaginas +
                '}');
    }

    public void leer(int n){
        for (int i=0; i<n ; i++){
            System.out.println("Estoy leyendo minuto " + i);
        }
    }

    public static Libro crearLibroConsola(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce titulo");
        String titulo = sc.nextLine();
        System.out.println("Introduce autor");
        String autor = sc.nextLine();
        System.out.println("Introduce genero");
        String genero = sc.nextLine();
        System.out.println("Introduce numero paginas");
        int n_paginas = sc.nextInt();
        sc.nextLine();
        System.out.println("Introduce año");
        int anio = sc.nextInt();
        sc.nextLine();

        return new Libro(titulo, autor,anio,n_paginas,genero);
    }
}
