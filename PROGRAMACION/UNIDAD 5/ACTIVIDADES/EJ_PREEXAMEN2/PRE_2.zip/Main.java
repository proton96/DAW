//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
    // to see how IntelliJ IDEA suggests fixing it.
    Obra o1 = Libro.crearLibroConsola();
    Obra o2 = Pelicula.crearPeliculaConsola();

    int valor = Obra.compararAnio(o1,o2);
    if(valor == 1){
        System.out.println("Obra 1 mayor");
    } else{
        System.out.println("Obra 2 mayor o igual");
    }
}
