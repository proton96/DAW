import java.util.Scanner;

public class Serie extends Obra{
    private int temporadas;
    private boolean enEmision;

    public Serie(String titulo, String autor, int anioPublicacion, int temporadas, boolean enEmision) {
        super(titulo, autor, anioPublicacion);
        this.temporadas = temporadas;
        this.enEmision = enEmision;
    }

    @Override
    public void mostrarResumen() {
        System.out.println( "Serie{" +
                "temporadas='" + temporadas + '\'' +
                ", enEmision=" + enEmision +
                '}');
    }

    @Override
    public void mostrarDetalles() {
        System.out.println( "Serie{" + "temporadas='" + temporadas + '\'' +
                "enEmision=" + enEmision +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", anioPublicacion=" + anioPublicacion +
                '}');
    }

    public void temporada(int n){
        for (int i=0; i<n ; i++){
            System.out.println("Estoy viendo la temporada " + i);
        }
    }
}
