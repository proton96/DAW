import java.util.Scanner;

public class Pelicula extends Obra {
    private String director;
    private int duracionMinutos;
    private boolean ganadoraOscar;

    public Pelicula(String titulo, String autor, int anioPublicacion, String director, int duracionMinutos, boolean ganadoraOscar) {
        super(titulo, autor, anioPublicacion);
        this.director = director;
        this.duracionMinutos = duracionMinutos;
        this.ganadoraOscar = ganadoraOscar;
    }

    @Override
    public void mostrarResumen() {
        System.out.println( "Pelicula{" +
                ", titulo='" + titulo + '\'' +
                ", director='" + director + '\'' +
                ", duracion=" + duracionMinutos +
                '}');
    }

    @Override
    public void mostrarDetalles() {
        super.mostrarDetalles();
        if(ganadoraOscar){
            System.out.println("Gano oscar");
        } else{
            System.out.println("No gano Oscar");
        }
    }

    public void reproducir(int n){
        for (int i=0; i<n ; i++){
            System.out.println("Estoy reproduciendo vez " + i);
        }
    }

    public static Pelicula crearPeliculaConsola(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce titulo");
        String titulo = sc.nextLine();
        System.out.println("Introduce autor");
        String autor = sc.nextLine();
        System.out.println("Introduce anio");
        int anio = sc.nextInt();
        sc.nextLine();
        System.out.println("Introduce director");
        String director = sc.nextLine();
        sc.nextLine();
        System.out.println("Introduce duracion minutos");
        int duracion = sc.nextInt();
        sc.nextLine();
        System.out.println("Introduce ganador de oscar");
        boolean ganador = sc.nextBoolean();

        return new Pelicula(titulo, autor,anio,director,duracion,ganador);
    }
}
