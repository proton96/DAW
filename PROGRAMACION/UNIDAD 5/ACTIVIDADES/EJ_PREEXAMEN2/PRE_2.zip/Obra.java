public abstract class Obra {
    protected String titulo;
    protected String autor;
    protected int anioPublicacion;

    public Obra(String titulo, String autor, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
    }

    public Obra() {
        this.titulo = "";
        this.autor = "";
        this.anioPublicacion = 0;
    }

    public abstract void mostrarResumen();

    public void mostrarDetalles() {
        System.out.println("Obra{" +
                "titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", anioPublicacion=" + anioPublicacion +
                '}');
    }

    public boolean esAntiguo(){
        return true;
    }

    /**
     * Este metedo compara 2 obras
     * @param o1
     * @param o2
     * @return 1 si o1 es mayor o 2 si o2 es mayor o igual.
     */
    public static int compararAnio(Obra o1, Obra o2){
        if(o1.anioPublicacion > o2.anioPublicacion){
            return 1;
        } else {
            return 2;
        }
    }
}
