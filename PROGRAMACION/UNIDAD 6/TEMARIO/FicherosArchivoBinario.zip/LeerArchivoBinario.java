import java.io.*;

public class LeerArchivoBinario {
    public static void leer(String ruta) {
        try (DataInputStream datos = new DataInputStream(new FileInputStream(ruta))) {
            while (datos.available() > 0) {
                String valor = datos.readUTF();
                System.out.println(valor);
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}