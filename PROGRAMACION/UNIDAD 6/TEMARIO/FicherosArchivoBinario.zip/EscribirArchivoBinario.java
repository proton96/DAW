import java.io.*;

public class EscribirArchivoBinario {
    public static void escrbir(String path, String datos, boolean sobreEscribir){
        try(DataOutputStream dop = new DataOutputStream(new FileOutputStream(path,sobreEscribir))){
            dop.writeUTF(datos);
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }
}
