public class Ejecutadora {
    public static void main(String[] args) {
        EscribirArchivoBinario.escrbir("C:\\Users\\2DAM\\Desktop\\Antonio\\src\\main\\Ficheros\\prueba.bin", "Antonio;25;Granada",true);
        LeerArchivoBinario.leer("C:\\Users\\2DAM\\Desktop\\Antonio\\src\\main\\Ficheros\\prueba.bin");
    }
}
