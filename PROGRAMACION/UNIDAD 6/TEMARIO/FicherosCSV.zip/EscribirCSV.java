import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirCSV {
    public static void escrbir(String path, String datos){
        BufferedWriter bw = null;
        try{
            FileWriter fw = new FileWriter(path, false);
            bw = new BufferedWriter(fw);
            bw.write(datos);
            bw.newLine();

        } catch (IOException e) {
            System.err.println("ALEX" + e.getMessage());
        } finally {
            if( bw != null) {
                try{
                    bw.close();
                } catch (IOException e){
                    System.out.println("Eror al cerrar fichero escritura");
                }
            }
        }
    }
}
