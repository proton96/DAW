import java.util.Scanner;

public class Ejecutadora {
    public static void main(String[] args) {
        EscribirCSV.escrbir("C:\\Users\\2DAM\\Desktop\\proyectos\\Antonio\\src\\main\\Ficheros\\prueba.csv", "Antonio;25;Granada");
        LeerCSV.leer("C:\\Users\\2DAM\\Desktop\\proyectos\\Antonio\\src\\main\\Ficheros\\prueba.csv");
    }
}
